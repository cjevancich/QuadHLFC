class ControlGw(object):
	command_id = {
		'SetRoll': 1,
		'SetPitch': 2,
		'Ping': 3,
		'SetY': 4,
		'SetYaw': 5}

	response_id = {
		'Pong': 1
	}

